export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCplfXNX_-WM_YD6Y4Rh3YPo2r0lu0loX0",
    authDomain: "ngcomponents.firebaseapp.com",
    databaseURL: "https://ngcomponents.firebaseio.com",
    projectId: "ngcomponents",
    storageBucket: "ngcomponents.appspot.com",
    messagingSenderId: "302063082822"
  }
};
