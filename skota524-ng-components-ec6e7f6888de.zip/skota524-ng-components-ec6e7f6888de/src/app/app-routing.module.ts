import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {TodoComponent} from "./components/todo/todo.component";
import {AppsComponent} from "./components/apps/apps.component";
import {AssignmentComponent} from "./components/assignment/assignment.component";
import {ChartsComponent} from "./components/charts/charts.component";
import {EasyPieChartComponent} from "ng2modules-easypiechart/easypiechart.component";
import {MessagesComponent} from "./components/messages/messages.component";
import {NotificationsComponent} from "./components/notifications/notifications.component";
import {ProfileCardComponent} from "./components/profile-card/profile-card.component";
import {ProjectCardComponent} from "./components/project-card/project-card.component";
import {RatingComponent} from "./components/rating/rating.component";
import {SearchComponent} from "./components/search/search.component";
import {StatCardComponent} from "./components/stat-card/stat-card.component";
import {StatComponentComponent} from "./components/stat-component/stat-component.component";
import {ThemePickerComponent} from "./components/theme-picker/theme-picker.component";
import {UserAccountComponent} from "./components/user-account/user-account.component";

const routes: Routes = [
  {
    path: 'components', children: [
      {path: 'apps', component: AppsComponent},
      {path: 'assignment', component: AssignmentComponent},
      {path: 'charts', component: ChartsComponent},
      {path: 'easy-pie-chart', component: EasyPieChartComponent},
      {path: 'messages', component: MessagesComponent},
      {path: 'notifications', component: NotificationsComponent},
      {path: 'profile-card', component: ProfileCardComponent},
      {path: 'project-card', component: ProjectCardComponent},
      {path: 'rating', component: RatingComponent},
      {path: 'search', component: SearchComponent},
      {path: 'stat-card', component: StatCardComponent},
      {path: 'stat-component', component: StatComponentComponent},
      {path: 'theme-picker', component: ThemePickerComponent},
      {path: 'todo', component: TodoComponent},
      {path: 'user-account', component: UserAccountComponent},
      {path: '', redirectTo: 'todo', pathMatch: 'full'}
    ]
  },
  {path: '', redirectTo: 'components', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
