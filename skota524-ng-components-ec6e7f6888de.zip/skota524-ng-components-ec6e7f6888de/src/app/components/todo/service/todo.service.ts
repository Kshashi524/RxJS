import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/of';

@Injectable()
export class TodoService {

  todoList = [
    {event: 'This is an open task', description: 'desc here', date: '2018-01-13', completed: false},
    {event: 'This is a completed task', description: 'desc here', date: '2018-01-13', completed: true},
    {
      event: 'This is a colored task',
      description: 'desc here',
      date: '2018-01-13',
      completed: false,
      color: 'blue-text'
    },
    {event: 'Check holidays with manager', description: 'desc here', date: '2018-01-13', completed: false},
    {
      event: '!!! This is important task !!!',
      description: 'desc here',
      date: '2018-01-13',
      completed: false,
      important: true,
      color: 'red-text'
    },
    {event: 'Todo 1', description: 'desc here', date: '2018-01-13', completed: false, color: 'red-text'},
    {event: 'Todo 2', description: 'desc here', date: '2018-01-13', completed: false, color: 'purple-text'}
  ];

  constructor() {
  }

  getTodoList(): Observable<Object> {
    return Observable.of(this.todoList);
  }

  addTodoList(todo: any): Observable<Object> {
    this.todoList.push(todo);
    return Observable.of(todo);
  }
}
