import {Component, Input, OnInit} from '@angular/core';
import {TodoDialogComponent} from './todo-dialog/todo-dialog.component';
import {MatDialog} from '@angular/material';
import {TodoService} from './service/todo.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.scss']
})
export class TodoComponent implements OnInit {

  todoList: any;
  selectedItem: any;
  eventDate: Date = new Date();
  @Input() expanded = true;

  constructor(private todoDialog: MatDialog, private todoService: TodoService) {
  }

  ngOnInit() {
    this.loadTodoList();
  }

  loadTodoList() {
    this.todoService.getTodoList().subscribe(data => {
      this.todoList = data;
    });
  }

  showTodoDialog(element?: any) {
    this.selectedItem = element ? {...element} : {};
    const todoDialog = this.todoDialog.open(TodoDialogComponent, {
      width: '30%',
      data: this.selectedItem
    });
    todoDialog.afterClosed().subscribe(data => {
    });
  }

}
