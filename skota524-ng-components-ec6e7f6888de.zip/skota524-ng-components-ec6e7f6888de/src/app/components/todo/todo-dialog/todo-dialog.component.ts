import {Component, Inject, OnInit} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {TodoService} from '../service/todo.service';

@Component({
  selector: 'app-todo-dialog',
  templateUrl: './todo-dialog.component.html',
  styleUrls: ['./todo-dialog.component.scss']
})
export class TodoDialogComponent implements OnInit {

  isNewObject = false;
  saveButtonLabel = 'Save';
  eventFormControl: FormControl = new FormControl('', [Validators.required]);
  descriptionFormControl: FormControl = new FormControl('', [Validators.required]);
  dateFormControl: FormControl = new FormControl('', [Validators.required]);

  constructor(public todoDialog: MatDialogRef<TodoDialogComponent>,
              private todoService: TodoService,
              @Inject(MAT_DIALOG_DATA) public data?: any) {
    this.isNewObject = (!data.event);
    this.saveButtonLabel = (data.event ? 'Update' : 'Save');
  }

  ngOnInit() {
  }

  getErrorMessage(field: string): string {
    if (field === 'event') {
      return 'Event cannot be empty';
    }
    if (field === 'description') {
      return 'Description cannot be empty';
    }
    if (field === 'date') {
      return 'Date cannot be empty';
    }
  }

  saveTodo() {
    this.todoService.addTodoList(this.data).subscribe(data => {
      this.todoDialog.close(data);
    });
  }
}
