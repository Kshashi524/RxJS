import {NgModule} from '@angular/core';
import {TodoComponent} from './todo.component';
import {AppCommonModule} from '../../common/common.module';
import {TodoDialogComponent} from './todo-dialog/todo-dialog.component';
import {TodoService} from './service/todo.service';

@NgModule({
  imports: [AppCommonModule],
  exports: [TodoComponent],
  declarations: [TodoComponent, TodoDialogComponent],
  providers: [TodoService],
  entryComponents: [TodoDialogComponent]
})
export class TodoModule {
}
