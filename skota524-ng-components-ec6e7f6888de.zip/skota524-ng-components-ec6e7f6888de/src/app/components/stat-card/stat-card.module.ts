import {NgModule} from '@angular/core';
import {StatCardComponent} from './stat-card.component';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [StatCardComponent],
  declarations: [StatCardComponent]
})
export class StatCardModule {
}
