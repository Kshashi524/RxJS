import {Component, OnInit} from '@angular/core';
import {MediaChange, ObservableMedia} from '@angular/flex-layout';

@Component({
  selector: 'app-apps',
  templateUrl: './apps.component.html',
  styleUrls: ['./apps.component.scss']
})
export class AppsComponent implements OnInit {
  mediaSubscription: any;
  cols: any = 3;
  apps = [
    {title: 'Calender', icon: 'event', color: 'blue-color'},
    {title: 'Email', icon: 'email', color: 'purple-color'},
    {title: 'Files', icon: 'insert_drive_file', color: 'teal-color'},
    {title: 'Report', icon: 'trending_up', color: 'cyan-color'},
    {title: 'News', icon: 'satellite', color: 'orange-color'},
    {title: 'Gallery', icon: 'image', color: 'brown-color'}
  ];

  constructor(private media: ObservableMedia) {
    this.mediaSubscription = this.media.subscribe((change: MediaChange) => this.adjustGridCols(change));
  }

  ngOnInit() {
  }

  adjustGridCols(change) {
    this.cols = (change.mqAlias === 'sm' || change.mqAlias === 'xs') ? 1 : 3;
  }
}
