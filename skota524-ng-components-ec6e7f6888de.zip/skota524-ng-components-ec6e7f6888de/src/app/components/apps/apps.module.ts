import {NgModule} from '@angular/core';
import {AppsComponent} from './apps.component';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [
    AppCommonModule
  ],
  exports: [AppsComponent],
  declarations: [AppsComponent]
})
export class AppsModule {
}
