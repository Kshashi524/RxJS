import {Component, OnInit} from '@angular/core';
import {isNullOrUndefined} from 'util';
import {ThemePickerService} from './service/theme-picker.service';
import {CacheService} from '../../common/cache/cache.service';
import {Cache} from 'cachefactory';


@Component({
  selector: 'app-theme-picker',
  templateUrl: './theme-picker.component.html',
  styleUrls: ['./theme-picker.component.scss']
})
export class ThemePickerComponent implements OnInit {

  currentTheme: string;
  themes: Array<any>;
  cache: Cache;

  constructor(private themePickerService: ThemePickerService, private cacheService: CacheService) {
    this.cache = this.cacheService.getCache('theme');
  }

  ngOnInit() {
    this.initCache();
    this.initThemes();
  }

  initCache() {
    if (!isNullOrUndefined(this.cache)) {
      const theme = this.cache.get('current_theme');
      if (!isNullOrUndefined(theme)) {
        this.currentTheme = this.cache.get('current_theme');
      }
    }
  }

  initThemes() {
    this.themes = [
      {name: 'Blue Theme', primary: '#2979FF', className: 'app-blue-theme'},
      {name: 'Pink Theme', primary: '#F50057', className: 'app-pink-theme'},
      {name: 'Cyan Theme', primary: '#00E5FF', className: 'app-cyan-theme'},
      {name: 'Orange Theme', primary: '#FF3D00', className: 'app-deep-orange-theme'},
      {name: 'Teal Theme', primary: '#1DE9B6', className: 'app-teal-theme'},
      {name: 'Purple Theme', primary: '#D500F9', className: 'app-purple-theme'}
    ];
  }

  loadTheme(theme: any) {
    this.themePickerService.loadTheme(theme.className);
    this.currentTheme = theme.className;
  }
}
