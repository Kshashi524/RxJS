import {NgModule} from '@angular/core';
import {ThemePickerComponent} from './theme-picker.component';
import {ThemePickerService} from './service/theme-picker.service';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [ThemePickerComponent],
  declarations: [ThemePickerComponent],
  providers: [ThemePickerService]
})
export class ThemePickerModule {
}
