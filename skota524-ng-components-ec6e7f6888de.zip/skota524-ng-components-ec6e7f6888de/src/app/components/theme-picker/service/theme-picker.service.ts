import {Injectable} from '@angular/core';
import {Subject} from "rxjs/Subject";

@Injectable()
export class ThemePickerService {

  themePickerSubject = new Subject<string>();
  themePickerState = this.themePickerSubject.asObservable();

  constructor() {
  }

  loadTheme(name: string) {
    this.themePickerSubject.next(name);
  }

}
