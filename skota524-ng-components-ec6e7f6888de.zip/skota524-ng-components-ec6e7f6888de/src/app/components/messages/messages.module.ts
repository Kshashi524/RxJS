import {NgModule} from '@angular/core';
import {MessagesComponent} from './messages.component';
import {AppCommonModule} from '../../common/common.module';
import {MessageService} from './service/message.service';

@NgModule({
  imports: [AppCommonModule],
  exports: [MessagesComponent],
  declarations: [MessagesComponent],
  providers: [MessageService]
})
export class MessagesModule {
}
