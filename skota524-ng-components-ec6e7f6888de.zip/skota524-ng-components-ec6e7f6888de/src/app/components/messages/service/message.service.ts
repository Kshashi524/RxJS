import {Injectable} from '@angular/core';
import {Subject} from 'rxjs/Subject';

@Injectable()
export class MessageService {

  messageSubject = new Subject<any>();
  messageState = this.messageSubject.asObservable();

  constructor() {
  }

  sendMessage(data: any) {
    this.messageSubject.next(data);
  }
}
