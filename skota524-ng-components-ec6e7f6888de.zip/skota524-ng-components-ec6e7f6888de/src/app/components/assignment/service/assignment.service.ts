import {Injectable} from '@angular/core';
import {Subject} from 'rxjs/Subject';

@Injectable()
export class AssignmentService {

  assignmentSubject = new Subject<any>();
  assignmentState = this.assignmentSubject.asObservable();

  constructor() {
  }

  createAssignment(data: any) {
    this.assignmentSubject.next(data);
  }
}
