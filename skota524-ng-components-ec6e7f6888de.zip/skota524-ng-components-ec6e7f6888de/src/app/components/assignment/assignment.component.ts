import {Component, OnInit} from '@angular/core';
import 'rxjs/add/observable/interval';
import {AssignmentService} from './service/assignment.service';

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.scss']
})
export class AssignmentComponent implements OnInit {

  tasks = [
    {title: 'Assignment 1', percentage: '40', color: 'primary'},
    {title: 'Assignment 2', percentage: '60', color: 'warn'},
    {title: 'Assignment 3', percentage: '25', color: 'accent'},
    {title: 'Assignment 4', percentage: '80', color: 'primary'},
    {title: 'Assignment 5', percentage: '70', color: 'warn'},
    {title: 'Assignment 6', percentage: '20', color: 'cyan'},
  ];
  subscription: any;
  status = false;

  constructor(private assignmentService: AssignmentService) {
    this.subscription = this.assignmentService.assignmentState.subscribe(data => this.assignmentReceived(data));
  }

  ngOnInit() {
  }

  assignmentReceived(data: any) {
    this.tasks.push(data);
    this.status = true;
    setTimeout(() => this.assignmentViewed(), 10000);
  }

  assignmentViewed() {
    this.status = false;
  }

}
