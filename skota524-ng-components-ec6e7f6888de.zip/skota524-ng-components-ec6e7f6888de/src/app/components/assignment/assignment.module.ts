import {NgModule} from '@angular/core';
import {AssignmentComponent} from './assignment.component';
import {AppCommonModule} from '../../common/common.module';
import {AssignmentService} from './service/assignment.service';

@NgModule({
  imports: [AppCommonModule],
  exports: [AssignmentComponent],
  declarations: [AssignmentComponent],
  providers: [AssignmentService]
})
export class AssignmentModule {
}
