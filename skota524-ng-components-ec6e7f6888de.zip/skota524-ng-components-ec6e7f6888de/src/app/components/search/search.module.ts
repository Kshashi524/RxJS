import {NgModule} from '@angular/core';
import {SearchComponent} from './search.component';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [SearchComponent],
  declarations: [SearchComponent]
})
export class SearchModule {
}
