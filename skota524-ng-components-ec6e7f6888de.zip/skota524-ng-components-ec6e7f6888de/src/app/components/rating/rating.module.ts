import {NgModule} from '@angular/core';
import {RatingComponent} from './rating.component';
import {AppCommonModule} from '../../common/common.module';
import {StarRatingModule} from 'angular-star-rating';

@NgModule({
  imports: [AppCommonModule, StarRatingModule],
  exports: [RatingComponent],
  declarations: [RatingComponent]
})
export class AppRatingModule {
}
