import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.scss']
})
export class RatingComponent implements OnInit {

  ratings = [
    {'number': 1, 'percentage': 20},
    {'number': 2, 'percentage': 36},
    {'number': 3, 'percentage': 45},
    {'number': 4, 'percentage': 29},
    {'number': 5, 'percentage': 7}
  ];

  constructor() {
  }

  ngOnInit() {
  }

}
