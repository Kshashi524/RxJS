import {NgModule} from '@angular/core';
import {NotificationsComponent} from './notifications.component';
import {AppCommonModule} from '../../common/common.module';
import {NotificationService} from './service/notification.service';

@NgModule({
  imports: [AppCommonModule],
  exports: [NotificationsComponent],
  declarations: [NotificationsComponent],
  providers: [NotificationService]
})
export class NotificationsModule {
}
