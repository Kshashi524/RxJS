import {Component, OnInit} from '@angular/core';
import {NotificationService} from './service/notification.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {

  messages = [
    {
      from: 'Kai',
      subject: 'Notification 1',
      content: 'Happy Coding !',
      date: 'now',
      avatar: '/assets/images/avatars/kai.png'
    },
    {
      from: 'Tyson',
      subject: 'Notification 2',
      content: 'Payment is due today',
      date: '1 min ago',
      avatar: '/assets/images/avatars/tyson.png'
    },
    {
      from: 'Ray',
      subject: 'Notification 3',
      content: 'Try changing the theme',
      date: '4 mins ago',
      avatar: '/assets/images/avatars/ray.png'
    },
    {
      from: 'Max',
      subject: 'Notification 4',
      content: 'Thank you for signing up',
      date: '30 mins ago',
      avatar: '/assets/images/avatars/max.png'
    },
    {
      from: 'Daichi',
      subject: 'Notification 5',
      content: 'Confirmation email sent',
      date: '1 hour ago',
      avatar: '/assets/images/avatars/daichi.png'
    },
    {
      from: 'Kenny',
      subject: 'Notification 6',
      content: 'Payment Successful',
      date: 'yesterday',
      avatar: '/assets/images/avatars/kenny.png'
    }
  ];
  subscription: any;
  status = false;

  constructor(private notificationService: NotificationService) {
    this.subscription = this.notificationService.notificationState.subscribe(data => this.notificationReceived(data));
  }

  ngOnInit() {
  }

  notificationReceived(data: any) {
    this.messages.push(data);
    this.status = true;
    setTimeout(() => this.notificationRead(), 10000);
  }

  notificationRead() {
    this.status = false;
  }

}
