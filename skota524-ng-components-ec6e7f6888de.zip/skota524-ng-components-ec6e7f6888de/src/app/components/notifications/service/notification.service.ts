import {Injectable} from '@angular/core';
import {Subject} from 'rxjs/Subject';

@Injectable()
export class NotificationService {

  notificationSubject = new Subject<any>();
  notificationState = this.notificationSubject.asObservable();

  constructor() {
  }

  sendNotification(data: any) {
    this.notificationSubject.next(data);
  }

}
