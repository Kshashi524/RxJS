import {NgModule} from '@angular/core';
import {ProjectCardComponent} from './project-card.component';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [ProjectCardComponent],
  declarations: [ProjectCardComponent]
})
export class ProjectCardModule {
}
