import {NgModule} from '@angular/core';
import {ProfileCardComponent} from './profile-card.component';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [ProfileCardComponent],
  declarations: [ProfileCardComponent]
})
export class ProfileCardModule {
}
