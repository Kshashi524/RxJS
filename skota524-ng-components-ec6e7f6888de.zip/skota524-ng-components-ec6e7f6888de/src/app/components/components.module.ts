import {NgModule} from '@angular/core';
import {TodoModule} from './todo/todo.module';
import {ThemePickerModule} from './theme-picker/theme-picker.module';
import {StatCardModule} from './stat-card/stat-card.module';
import {StatComponentModule} from './stat-component/stat-component.module';
import {ChartsModule} from './charts/charts.module';
import {EasyPieComponentsModule} from './easy-pie-components/easy-pie-components.module';
import {AppsModule} from './apps/apps.module';
import {AssignmentModule} from './assignment/assignment.module';
import {NotificationsModule} from './notifications/notifications.module';
import {UserAccountModule} from './user-account/user-account.module';
import {MessagesModule} from './messages/messages.module';
import {SearchModule} from './search/search.module';
import {ProjectCardModule} from './project-card/project-card.module';
import {ProfileCardModule} from './profile-card/profile-card.module';
import {AppRatingModule} from './rating/rating.module';

const COMPONENT_MODULES = [TodoModule, ThemePickerModule, StatCardModule, ChartsModule,
  StatComponentModule, EasyPieComponentsModule];

const COMPONENT_MODULES_2 = [AppsModule, AssignmentModule, NotificationsModule, UserAccountModule, MessagesModule, SearchModule];

const COMPONENT_MODULES_3 = [ProjectCardModule, ProfileCardModule, AppRatingModule];

@NgModule({
  imports: [COMPONENT_MODULES, COMPONENT_MODULES_2, COMPONENT_MODULES_3],
  exports: [COMPONENT_MODULES, COMPONENT_MODULES_2, COMPONENT_MODULES_3],
  declarations: []
})
export class ComponentsModule {
}
