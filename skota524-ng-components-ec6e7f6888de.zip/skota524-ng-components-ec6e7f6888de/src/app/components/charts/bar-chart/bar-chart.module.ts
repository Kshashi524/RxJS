import {NgModule} from '@angular/core';
import {BarChartComponent} from './bar-chart.component';
import {AppCommonModule} from '../../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [BarChartComponent],
  declarations: [BarChartComponent]
})
export class BarChartModule {
}
