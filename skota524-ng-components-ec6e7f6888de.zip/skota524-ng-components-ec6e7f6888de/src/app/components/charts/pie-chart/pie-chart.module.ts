import {NgModule} from '@angular/core';
import {PieChartComponent} from './pie-chart.component';
import {AppCommonModule} from '../../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [PieChartComponent],
  declarations: [PieChartComponent]
})
export class PieChartModule {
}
