import {NgModule} from '@angular/core';
import {DoughnutChartComponent} from './doughnut-chart.component';
import {AppCommonModule} from '../../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [DoughnutChartComponent],
  declarations: [DoughnutChartComponent]
})
export class DoughnutChartModule {
}
