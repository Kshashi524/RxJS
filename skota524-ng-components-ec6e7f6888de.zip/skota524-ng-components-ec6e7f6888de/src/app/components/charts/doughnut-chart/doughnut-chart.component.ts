import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-doughnut-chart',
  templateUrl: './doughnut-chart.component.html',
  styleUrls: ['./doughnut-chart.component.scss']
})
export class DoughnutChartComponent implements OnInit {

  doughnutChartLabels: string[] = ['Chrome', 'Opera', 'Firefox', 'Edge', 'Vivaldi'];
  doughnutChartData: number[] = [350, 450, 100, 150, 50];
  doughnutChartType = 'doughnut';

  constructor() {
  }

  chartClicked(e: any): void {
    console.log(e);
  }

  chartHovered(e: any): void {
    console.log(e);
  }

  ngOnInit() {
  }

  randomize() {
  }
}
