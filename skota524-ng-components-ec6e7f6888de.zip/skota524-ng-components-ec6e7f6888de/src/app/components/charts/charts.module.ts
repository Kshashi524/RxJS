import {NgModule} from '@angular/core';
import {ChartsComponent} from './charts.component';
import {AppCommonModule} from '../../common/common.module';
import {BarChartModule} from './bar-chart/bar-chart.module';
import {DoughnutChartModule} from './doughnut-chart/doughnut-chart.module';
import {LineChartModule} from './line-chart/line-chart.module';
import {PieChartModule} from './pie-chart/pie-chart.module';

const CHARTS_MODULE = [BarChartModule, DoughnutChartModule, LineChartModule, PieChartModule];

@NgModule({
  imports: [AppCommonModule, CHARTS_MODULE],
  exports: [ChartsComponent],
  declarations: [ChartsComponent]
})
export class ChartsModule {
}
