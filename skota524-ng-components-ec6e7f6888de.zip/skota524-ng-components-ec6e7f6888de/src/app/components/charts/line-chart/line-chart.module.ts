import {NgModule} from '@angular/core';
import {LineChartComponent} from './line-chart.component';
import {AppCommonModule} from '../../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [LineChartComponent],
  declarations: [LineChartComponent]
})
export class LineChartModule {
}
