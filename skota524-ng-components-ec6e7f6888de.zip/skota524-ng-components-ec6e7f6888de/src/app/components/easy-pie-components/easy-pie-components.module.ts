import {NgModule} from '@angular/core';
import {EasyPieComponentsComponent} from './easy-pie-components.component';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [EasyPieComponentsComponent],
  declarations: [EasyPieComponentsComponent]
})
export class EasyPieComponentsModule {
}
