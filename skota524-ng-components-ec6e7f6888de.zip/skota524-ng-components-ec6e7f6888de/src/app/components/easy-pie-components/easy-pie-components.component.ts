import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-easy-pie-components',
  templateUrl: './easy-pie-components.component.html',
  styleUrls: ['./easy-pie-components.component.scss']
})
export class EasyPieComponentsComponent implements OnInit {

  percent = 80;
  options = {
    barColor: '#ef1e25',
    trackColor: '#f9f9f9',
    scaleColor: '#dfe0e0',
    scaleLength: 5,
    lineCap: 'round',
    lineWidth: 3,
    size: 110,
    rotate: 0,
    animate: {
      duration: 1000,
      enabled: true
    }
  };

  constructor() {
  }

  ngOnInit() {
  }

}
