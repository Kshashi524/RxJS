import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {EasyPieComponentsComponent} from './easy-pie-components.component';

describe('EasyPieComponentsComponent', () => {
  let component: EasyPieComponentsComponent;
  let fixture: ComponentFixture<EasyPieComponentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EasyPieComponentsComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EasyPieComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
