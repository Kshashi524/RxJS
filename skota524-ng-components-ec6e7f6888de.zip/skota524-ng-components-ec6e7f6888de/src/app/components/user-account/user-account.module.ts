import {NgModule} from '@angular/core';
import {UserAccountComponent} from './user-account.component';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [UserAccountComponent],
  declarations: [UserAccountComponent]
})
export class UserAccountModule {
}
