import {NgModule} from '@angular/core';
import {StatComponentComponent} from './stat-component.component';
import {AppCommonModule} from '../../common/common.module';

@NgModule({
  imports: [AppCommonModule],
  exports: [StatComponentComponent],
  declarations: [StatComponentComponent]
})
export class StatComponentModule {
}
