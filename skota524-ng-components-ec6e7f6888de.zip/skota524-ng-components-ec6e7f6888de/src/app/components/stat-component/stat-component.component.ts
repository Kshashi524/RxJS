import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-stat-component',
  templateUrl: './stat-component.component.html',
  styleUrls: ['./stat-component.component.scss']
})
export class StatComponentComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
