import {ChangeDetectorRef, Component, OnDestroy, OnInit, Renderer2} from '@angular/core';
import {CacheService} from './common/cache/cache.service';
import {ThemePickerService} from './components/theme-picker/service/theme-picker.service';
import {isNullOrUndefined} from 'util';
import {Cache} from 'cachefactory';
import {NotificationService} from './components/notifications/service/notification.service';
import {AssignmentService} from './components/assignment/service/assignment.service';
import {MessageService} from './components/messages/service/message.service';
import {ToastrService} from 'ngx-toastr';
import {MediaMatcher} from "@angular/cdk/layout";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  appliedTheme = 'app-blue-theme';
  themePickerSubscription: any;
  cache: Cache;

  mobileQuery: MediaQueryList;

  fillerNav = [
    {'path': '/components/apps', name: 'Apps'},
    {'path': '/components/assignment', name: 'Assignment'},
    {'path': '/components/charts', name: 'Charts'},
    {'path': '/components/easy-pie-chart', name: 'EasyPieChart'},
    {'path': '/components/messages', name: 'Messages'},
    {'path': '/components/notifications', name: 'Notifications'},
    {'path': '/components/profile-card', name: 'ProfileCard'},
    {'path': '/components/project-card', name: 'ProjectCard'},
    {'path': '/components/rating', name: 'Rating'},
    {'path': '/components/search', name: 'Search'},
    {'path': '/components/stat-card', name: 'StatCard'},
    {'path': '/components/stat-component', name: 'StatComponent'},
    {'path': '/components/theme-picker', name: 'ThemePicker'},
    {'path': '/components/todo', name: 'Todo'},
    {'path': '/components/user-account', name: 'UserAccount'}
  ];
  //Array(50).fill(0).map((_, i) => `Nav Item ${i + 1}`);

  fillerContent = Array(50).fill(0).map(() =>
    `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
       labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
       laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
       voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
       cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.`);

  private _mobileQueryListener: () => void;

  constructor(private themePickerService: ThemePickerService,
              private cacheService: CacheService,
              private renderer: Renderer2,
              private toastr: ToastrService,
              private messageService: MessageService,
              private assignmentService: AssignmentService,
              private notificationService: NotificationService,
              private changeDetectorRef: ChangeDetectorRef,
              private media: MediaMatcher) {
    this.themePickerSubscription = this.themePickerService.themePickerState.subscribe(theme => this.applyTheme(theme));
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.initThemeCache();

  }

  ngOnInit() {
  }

  removeTheme(theme: string) {
    this.renderer.removeClass(document.body, theme);
  }

  applyTheme(theme: string) {
    this.removeTheme(this.appliedTheme);
    this.renderer.addClass(document.body, theme);
    this.appliedTheme = theme;
    this.cache.put('current_theme', theme);
  }

  initThemeCache() {
    this.cache = this.cacheService.getCache('theme');
    const theme = this.cache.get('current_theme');
    if (isNullOrUndefined(theme)) {
      this.applyTheme('app-blue-theme');
    } else {
      this.applyTheme(theme);
    }
  }

  createMessage() {
    const data = {
      from: 'Kenny',
      subject: 'Notification 6',
      content: 'Payment Successful',
      date: 'yesterday',
      avatar: '/assets/img/avatars/kenny.png'
    };
    this.messageService.sendMessage(data);
  }

  createAssignment() {
    const data = {title: 'Assignment 6', percentage: '20', color: 'cyan'};
    this.assignmentService.createAssignment(data);
  }

  createNotification() {
    const data = {
      from: 'Kenny',
      subject: 'Notification 6',
      content: 'Payment Successful',
      date: 'yesterday',
      avatar: '/assets/img/avatars/kenny.png'
    };
    this.toastr.success(data.content, data.subject);
    this.notificationService.sendNotification(data);
  }

  ngOnDestroy() {
    this.themePickerSubscription.unsubscribe();
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

}
