import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FlexLayoutModule} from '@angular/flex-layout';
import {MaterialModule} from './material/material.module';
import {CacheModule} from './cache/cache.module';
import {AppDateAdapter, DATE_FORMATS} from './material/adapter/app-date-adapter';
import {DateAdapter, MAT_DATE_FORMATS} from '@angular/material';
import {NgProgressModule} from '@ngx-progressbar/core';
import {ChartsModule} from 'ng2-charts/ng2-charts';
import {EasyPieChartModule} from 'ng2modules-easypiechart';

const COMMON_MODULES = [BrowserModule, ReactiveFormsModule, FormsModule, FlexLayoutModule, MaterialModule, NgProgressModule, ChartsModule, EasyPieChartModule];

@NgModule({
  imports: [CacheModule, COMMON_MODULES],
  exports: [COMMON_MODULES],
  providers: [
    {provide: DateAdapter, useClass: AppDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: DATE_FORMATS}
  ]
})
export class AppCommonModule {
}
