import {NgModule} from '@angular/core';
import {CacheService} from './cache.service';

@NgModule({
  imports: [],
  providers: [CacheService]
})
export class CacheModule {
}
