import {Injectable} from '@angular/core';
import {CacheFactory, CacheOptions} from 'cachefactory';

@Injectable()
export class CacheService {

  options: CacheOptions = {
    deleteOnExpire: 'aggressive',
    cacheFlushInterval: 30 * 60 * 1000,
    storageMode: 'localStorage',
    maxAge: 50 * 60 * 1000
  };

  private cacheFactory: CacheFactory = new CacheFactory();

  constructor() {
  }

  getCache(cacheName: string): any {
    let cache;
    if (!this.cacheFactory.exists(cacheName)) {
      cache = this.cacheFactory.createCache(cacheName, this.options);
    } else {
      cache = this.cacheFactory.get(cacheName);
    }
    return cache;
  }

  clearCache(): any {
    this.cacheFactory.clearAll();
  }
}
