import {NativeDateAdapter} from '@angular/material';
import {Injectable} from '@angular/core';


export const DATE_FORMATS = {
  parse: {
    dateInput: {month: 'short', year: 'numeric', day: 'numeric'}
  },
  display: {
    // dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
    dateInput: 'input',
    monthYearLabel: {year: 'numeric', month: 'short'},
    dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
    monthYearA11yLabel: {year: 'numeric', month: 'long'},
  }
};

@Injectable()
export class AppDateAdapter extends NativeDateAdapter {
  format(date: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      date.setMinutes(date.getMinutes() + date.getTimezoneOffset());
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      // return this._to2digit(day) + '/' + this._to2digit(month) + '/' + year;
      return `${this._to2digit(month)}-${this._to2digit(day)}-${year}`;
    } else {
      return date.toDateString();
    }
  }

  private _to2digit(n: number) {
    return ('00' + n).slice(-2);
  }
}
